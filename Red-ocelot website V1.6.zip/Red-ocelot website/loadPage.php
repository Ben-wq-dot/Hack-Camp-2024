<?php

    // retrieve selected page and store in a variable
    $requested_page = $_POST['selectedPage'];
    
    // load correct page based on the contents of the variable
    switch($requested_page){
        case "monthly":
            header("Location:commit history monthly.php");
        break;
        case "daily":
            header("Location:commit history daily.php");
        break;
        case "yearly":
            header("Location:commit history yearly.php");
        break;
        case "weekly":
            header("Location:commit history weekly.php");
        break;
    }
    