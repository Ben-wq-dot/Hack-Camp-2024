<?php
 
$pageTitle = 'Charts';
include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/charts.phtml';         // Content only
include __DIR__ . '/Views/template/footer.phtml'; // Include the footer

