<?php
 
$pageTitle = 'Charts';

include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/file size.phtml';         // Content only
 
//declare database credentials
$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";

//connect to the database with credentials
$conn = new PDO("pgsql:host=$host; port=$port; dbname=$dbname; user=$user; password=$password");

// query for all 5 bars of the bar chart
$statement1 = $conn->query("
    SELECT COUNT(line_count) as num FROM files WHERE line_count=0;
");
 
$statement2 = $conn->query("
    SELECT COUNT(line_count) as num FROM files WHERE line_count BETWEEN 1 AND 50;
");
 
$statement3 = $conn->query("
    SELECT COUNT(line_count) as num FROM files WHERE line_count BETWEEN 50 AND 150;
");
 
$statement4 = $conn->query("
    SELECT COUNT(line_count) as num FROM files WHERE line_count BETWEEN 150 AND 1000;
");
 
$statement5 = $conn->query("
    SELECT COUNT(line_count) as num FROM files WHERE line_count>1000;
");
 
//fetch all results and store in variables
$results1 = $statement1->fetch();
$y1 = $results1[0];
 
$results2 = $statement2->fetch();
$y2 = $results2[0];
 
$results3 = $statement3->fetch();
$y3 = $results3[0];
 
$results4 = $statement4->fetch();
$y4 = $results4[0];
 
$results5 = $statement5->fetch();
$y5 = $results5[0];
 
//create datapoints array
$datapoints=[
    array("y"=>$y1, "label"=> "0"),
    array("y"=>$y2, "label"=> "1-50"),
    array("y"=>$y3, "label"=> "50-150"),
    array("y"=>$y4, "label"=> "150-1000"),
    array("y"=>$y5, "label"=> "1000+")
   
];
?>
 
<!DOCTYPE HTML>
<html>
<head>  
<script>
window.onload = function () {
    // create bar chart
    var barChart = new CanvasJS.Chart("barChartContainer", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light1",
        title: {
            text: "Line Count Ranges vs Number of Occurrences"
        },
        axisX: {
            title: "Line Count Ranges",
            labelAngle: -45 // Tilt labels for readability
        },
        axisY: {
            title: "Number of Occurrences",
            includeZero: true
        },
        data: [{
            type: "bar",
            dataPoints: <?php echo json_encode($datapoints, JSON_NUMERIC_CHECK); ?>
        }]
    });
    //display bar chart
    barChart.render();
}
</script>
</head>
<body>
    <br>
    <!-- Bar Chart -->
    <div id="barChartContainer" style="height: 370px; width: 80%;"></div>
    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
</body>
</html>

<?php
include __DIR__ . '/Views/template/footer.phtml'; // Include the footer