<?php

$pageTitle = 'Charts';

include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/commit_history.phtml'; // Content only

// Declare database credentials
$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";

// Connect to the database
$conn = new PDO("pgsql:host=$host; port=$port; dbname=$dbname; user=$user; password=$password");

// Query the database for daily commits
$lineResults = $conn->query("
    SELECT
        DATE(date) AS commit_day, -- Extract the date part only
        COUNT(*) AS NumberOfCommits
    FROM
        commits
    GROUP BY
        DATE(date) -- Group by date only, ignoring the time
    ORDER BY
        DATE(date) ASC; -- Sort results by date
");


/* // Create an array of data points
$lineDataPoints = [];
while ($row = $lineResults->fetch(PDO::FETCH_ASSOC)) {
    $lineDataPoints[] = [
        "x" => strtotime($row['commit_day']) * 1000, // Convert date to JS timestamp
        "y" => (int)$row['NumberOfCommits']
    ];
} */

$lineDataPoints = [];
while ($row = $lineResults->fetch(PDO::FETCH_ASSOC)) {
    $lineDataPoints[] = [
        "x" => strtotime($row['commit_day']) * 1000, // Convert date to JS timestamp
        "y" => (int)$row['NumberOfCommits'] // Commit count
    ];
}

// Debug to confirm the structure of $lineDataPoints
echo "<pre>";
print_r($lineDataPoints);
echo "</pre>";
die();


?>

<!DOCTYPE HTML>
<html>
<head>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
<script>
window.onload = function () {
    var lineChart = new CanvasJS.Chart("lineChartContainer", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light2",
        title: {
            text: "Commits Over Time (Daily)"
        },
        axisX: {
            title: "Days",
            valueFormatString: "MMM DD", // Shorter date format
            labelAngle: -45 // Tilt labels for readability
        },
        axisY: {
            title: "Number of Commits",
            includeZero: true
        },
        data: [{
            type: "line",
            xValueType: "dateTime", // Handle timestamps for smoother rendering
            dataPoints: <?php echo json_encode($lineDataPoints, JSON_NUMERIC_CHECK); ?>
        }]
    });
    lineChart.render();
}
</script>
</head>
<body>
    <div id="lineChartContainer" style="height: 370px; width: 100%;"></div>
</body>
</html>

<?php include __DIR__ . '/Views/template/footer.phtml'; // Include the footer ?>
