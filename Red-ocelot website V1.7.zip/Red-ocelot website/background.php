<?php
$pageTitle = 'Background';
include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/background.phtml';     // Content only
include __DIR__ . '/Views/template/footer.phtml'; // Include the footer
