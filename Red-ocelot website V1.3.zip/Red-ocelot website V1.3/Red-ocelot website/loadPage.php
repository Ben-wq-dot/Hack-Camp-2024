<?php
echo "IM LOADING A PAGE";


    $requested_page = $_POST['selectedPage'];
    echo $requested_page;
    
    switch($requested_page){
        case "monthly":
            header("Location:commit history monthly.php");
        break;
        case "daily":
            header("Location:commit history daily.php");
        break;
        case "yearly":
            header("Location:commit history yearly.php");
        break;
    }
    
