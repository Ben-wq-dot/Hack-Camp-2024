<?php
 
$pageTitle = 'Charts';
include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/charts.phtml';         // Content only
 
$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";
 
$conn = new PDO("pgsql:host=$host; port=$port; dbname=$dbname; user=$user; password=$password");

// Query for line chart: Number of commits grouped by month and year
$lineResults = $conn->query("
    SELECT
        TO_CHAR(date, 'Day Mon YYYY') AS commit_day,
        COUNT(*) AS NumberOfCommits
    FROM
        commits
    GROUP BY
        TO_CHAR(date, 'Day Mon YYYY')
    ORDER BY
        MIN(date) ASC;
");
 
// Create an array for line chart data points
$lineDataPoints = [];
while ($row = $lineResults->fetch(PDO::FETCH_ASSOC)) {
    $lineDataPoints[] = [
        "label" => $row['commit_day'], // Month-Year label for X-axis
        "y" => (int)$row['numberofcommits'] // Number of commits for each month
    ];
}
?>
 
<!DOCTYPE HTML>
<html>
<head>  
<script>
window.onload = function () {
    // Line Chart
    var lineChart = new CanvasJS.Chart("lineChartContainer", {
        animationEnabled: true,
        exportEnabled: true,
        theme: "light2",
        title: {
            text: "Commits Over Time (Daily)"
        },
        axisX: {
            title: "Days",
            interval: 1,
            labelAngle: -45 // Tilt labels for better readability
        },
        axisY: {
            title: "Number of Commits",
            includeZero: true
        },
        data: [{
            type: "line",
            dataPoints: <?php echo json_encode($lineDataPoints, JSON_NUMERIC_CHECK); ?>
        }]
    });
    lineChart.render();
}
</script>
</head>
<body>
    <br>
    <!-- Line Chart -->
    <div id="lineChartContainer" style="height: 370px; width: 100%;"></div>
    <script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
</body>
</html>

<?php
include __DIR__ . '/Views/template/footer.phtml'; // Include the footer

 