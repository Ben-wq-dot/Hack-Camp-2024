<?php

include __DIR__ . '/Views/template/header.phtml'; // Include the header

// Database credentials
$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";

// Connect to the database
$conn = new PDO("pgsql:host=$host; port=$port; dbname=$dbname; user=$user; password=$password");

// Query the database
$results = $conn->query("
    SELECT
        line_count,
        functional_line_count,
        (line_count - functional_line_count) AS nonfunctional_line_count
    FROM
        files
    WHERE
        (line_count - functional_line_count) > 0;
");

// Prepare raw data arrays
$data = [];
$x_values = [];
$y_values = [];

while ($row = $results->fetch(PDO::FETCH_ASSOC)) {
    $x = $row['functional_line_count'];
    $y = $row['nonfunctional_line_count'];
    $z = $row['line_count'];
    
    $x_values[] = $x;
    $y_values[] = $y;
    $data["$x-$y"] = $z; // Map (x, y) -> z
}

// Create unique, sorted arrays for x and y
$x_values = array_values(array_unique($x_values));
sort($x_values);
$y_values = array_values(array_unique($y_values));
sort($y_values);

// Create the 2D z-matrix
$z_matrix = [];
foreach ($y_values as $y) {
    $row = [];
    foreach ($x_values as $x) {
        $row[] = $data["$x-$y"] ?? 0; // Use 0 if no z-value is found
    }
    $z_matrix[] = $row;
}

// Convert data arrays to JSON
$x_data_json = json_encode($x_values);
$y_data_json = json_encode($y_values);
$z_data_json = json_encode($z_matrix);
?>

<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<body>
    <div id="myDiv" style="height: 500px; width: 100%;"></div>
    <script>
        // Data for the 3D chart
        var data = [{
            x: <?php echo $x_data_json; ?>,  // Functional Line Count
            y: <?php echo $y_data_json; ?>,  // Nonfunctional Line Count
            z: <?php echo $z_data_json; ?>,  // Total Line Count (2D matrix)
            type: 'surface'
        }];

        // Layout with tight bounds
        var layout = {
            title: '3D Chart',
            autosize: true,
            width: 800,
            height: 500,
            margin: {
                l: 65,
                r: 50,
                b: 65,
                t: 90
            },
            scene: {
                xaxis: { title: 'Functional Line Count' },
                yaxis: { title: 'Nonfunctional Line Count' },
                zaxis: { title: 'Total Line Count' }
            }
        };

        // Render the 3D chart
        Plotly.newPlot('myDiv', data, layout);
    </script>
</body>
</html>