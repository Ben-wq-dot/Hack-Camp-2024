<?php

// Database Credentials
$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // When handling the AJAX request, output JSON only, no extra HTML
    header('Content-Type: application/json');

    try {
        // Connect to the database
        $conn = new PDO("pgsql:host=$host;port=$port;dbname=$dbname", $user, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Get selected repositories from POST and pagination parameters
        $selectedBranches = $_POST['branches'] ?? [];
        $page = isset($_POST['page']) ? (int)$_POST['page'] : 1;
        $limit = 10; // Number of items per page
        $offset = ($page - 1) * $limit;

        if (empty($selectedBranches)) {
            echo json_encode(['error' => 'No repositories selected.']);
            exit;
        }

        // Prepare placeholders for queries
        $placeholders = implode(',', array_fill(0, count($selectedBranches), '?'));

        // Query the database
        $sql = "
        SELECT 
            split_part(path, '/', 1) AS top_level_dir, 
            branch_id, 
            COUNT(*) AS file_count, 
            SUM(line_count) AS total_lines_of_code
        FROM files
        WHERE branch_id IN ($placeholders)
        GROUP BY top_level_dir, branch_id
        ORDER BY total_lines_of_code DESC
        LIMIT $limit OFFSET $offset;
        ";

        $stmt = $conn->prepare($sql);
        $stmt->execute($selectedBranches);
        $files = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Format the data for the bar chart
        $chartData = [];
        foreach ($files as $row) {
            $label = (!empty($row['top_level_dir']) ? $row['top_level_dir'] : "Unknown") 
                    . " (Branch " . (!empty($row['branch_id']) ? $row['branch_id'] : "Unknown") . ")";
            $chartData[] = [
                'label' => $label,
                'y' => (!empty($row['total_lines_of_code']) ? (int)$row['total_lines_of_code'] : 0),
            ];
        }

        // Return JSON response
        echo json_encode(['data' => $chartData]);
    } catch (PDOException $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }

    // Stop execution after returning JSON to avoid adding HTML
    exit;
}

// If not a POST request, this is likely a GET request for the page itself.
// Include the header, main .phtml (with the form and chart container), and footer.
include __DIR__ . '/Views/template/header.phtml';
include __DIR__ . '/Views/FileSizeBarChart.phtml';
include __DIR__ . '/Views/template/footer.phtml';
