<?php


$pageTitle = 'Charts';
include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/charts.phtml';         // Content only


$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";

$conn = new PDO("pgsql:host=$host; port=$port; dbname=$dbname; user=$user; password=$password");

// Query the database
$results = $conn->query("SELECT author, COUNT(*) AS NumberOfCommits FROM commits GROUP BY author ORDER BY NumberOfCommits DESC;");

// Create an array for data points
$dataPoints = [];
while ($row = $results->fetch(PDO::FETCH_ASSOC)) {
    $dataPoints[] = [
        "label" => $row['author'],
        "y" => (int)$row['numberofcommits']
    ];
}
?>

<!DOCTYPE HTML>
<html>
<head>  
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    exportEnabled: true,
    theme: "light1", // "light1", "light2", "dark1", "dark2"
    title:{
        text: "Number of Commits Sorted by Author."
    },
    data: [{
        type: "doughnut", //change type to bar, line, area, pie, etc  
        dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
    }]
});
chart.render();
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
</body>
</html>
<?php
include __DIR__ . '/Views/template/footer.phtml'; // Include the footer