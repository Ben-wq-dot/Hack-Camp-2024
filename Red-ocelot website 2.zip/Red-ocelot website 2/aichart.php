<?php
$pageTitle = 'ai';
include __DIR__ . '/Views/template/header.phtml'; // Include the header

exec('python machine_learning/model.py', $output, $retval);

 // Decode the Python output
 $data = isset($output[0]) ? json_decode($output[0], true) : [];
 $chartData = [];
 if (is_array($data) && count($data) >= 2) {
	 $chartData = [
		 ["label" => "Add Feature", "y" => $data[0]],
		 ["label" => "Refactor Code", "y" => $data[1]]
	 ];
 }
?>

<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function() {
var chartData = <?php echo json_encode($chartData, JSON_NUMERIC_CHECK); ?>;

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "AI Chart"
	},
	data: [{
		type: "pie",
		startAngle: 240,
		indexLabel: "{label}: {y}",
		dataPoints: chartData
	}]
});
chart.render();
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://cdn.canvasjs.com/canvasjs.min.js"></script>
</body>
</html>
<?php
include __DIR__ . '/Views/template/footer.phtml'; // Include the footer