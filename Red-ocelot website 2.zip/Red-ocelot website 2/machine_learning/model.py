import psycopg2
import spacy
import json
 
db_config = {
    'dbname': 'postgres',
    'user': 'postgres',
    'password': 'admin',
    'host': 'localhost',
    'port': 5432          
}
 
connection = psycopg2.connect(**db_config)
cursor = connection.cursor()
 
query = "SELECT id, message FROM commits;"
cursor.execute(query)
 
commit_messages = cursor.fetchall() 
 
nlp = spacy.load('machine_learning/text_categorizer_model')
 
ADD_FEATURE_COUNT = 0
REFACTOR_COUNT = 0
 
for id, message in commit_messages:
    doc = nlp(message)
    if doc.cats['ADD_FEATURE'] > doc.cats['REFACTOR_CODE']:
        category = 'ADD_FEATURE'
        ADD_FEATURE_COUNT += 1
    else:
        category = 'REFACTOR_CODE'
        REFACTOR_COUNT += 1

results = [ADD_FEATURE_COUNT, REFACTOR_COUNT]

print(json.dumps(results))