<?php
 
$pageTitle = 'Charts';
include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/charts.phtml';         // Content only
 
$host = "localhost";
$user = "postgres";
$password = "admin";
$dbname = "postgres";
$port = "5432";
 
$conn = new PDO("pgsql:host=$host; port=$port; dbname=$dbname; user=$user; password=$password");
 


include __DIR__ . '/Views/template/footer.phtml'; // Include the footer

 