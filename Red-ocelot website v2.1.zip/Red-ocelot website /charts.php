<?php
    $pageTitle = 'Charts';
    include __DIR__ . '/Views/template/header.phtml'; // Include the header
    include __DIR__ . '/Views/charts.phtml';          // Content only

$output = null;
$retval = null;

exec('machine learning/model.py', $retval);


echo $retval;
echo $output;


//var_dump("arry shape is: " . $output);

/*foreach ($output as &$value) {
    echo $value;
}
*/
?>