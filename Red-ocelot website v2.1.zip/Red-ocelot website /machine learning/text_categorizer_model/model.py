import spacy

nlp = spacy.load("text_categorizer_model")

doc = nlp("Refactor the user management system")

#get the scores for each catergory
print(doc.cats)

#Determine the most likely category
if doc.cats["ADD_FEATURE"] > doc.cats["REFACTOR_CODE"]:
    print("Category: Adding Feature")
else:
    print("Category: Refactoring Code")