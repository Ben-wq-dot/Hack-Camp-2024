<?php
 
$pageTitle = 'Charts';

include __DIR__ . '/Views/template/header.phtml'; // Include the header
include __DIR__ . '/Views/commit history.phtml';         // Content only